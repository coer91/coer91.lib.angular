const appSettings = { 
    appInfo: {
        id: 0,
        project: '',
        title: 'COER 91',
        version: '0.0.0', 
        forCompany: ''
    },
    webAPI: {
        development: {},
        staging: {},
        production: {}
    }  
}