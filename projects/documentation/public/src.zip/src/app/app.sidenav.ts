import { IMenu } from "coer91.angular/interfaces";

export const NAVIGATION: IMenu[] = [
  
];