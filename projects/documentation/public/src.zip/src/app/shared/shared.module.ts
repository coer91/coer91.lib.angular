//Modules
import { NgModule } from '@angular/core'; 
import { coer91Module } from 'coer91.angular'; 
 
@NgModule({
    imports: [coer91Module],
    exports: [coer91Module]
})
export class SharedModule { }