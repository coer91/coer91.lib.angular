import { Routes } from '@angular/router';
import { ROUTES_91 } from 'coer91.angular/core'; 

export const ROUTES = ([ 

] as Routes).concat(ROUTES_91);