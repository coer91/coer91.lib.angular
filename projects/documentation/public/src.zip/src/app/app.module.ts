//Modules
import { NgModule } from '@angular/core';   
import { SharedModule } from './shared/shared.module';

@NgModule({ 
    declarations: [
        
    ],
    imports: [SharedModule],
    exports: [SharedModule]
})
export class AppModule { }